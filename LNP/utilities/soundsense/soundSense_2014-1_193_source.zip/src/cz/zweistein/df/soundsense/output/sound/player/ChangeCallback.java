package cz.zweistein.df.soundsense.output.sound.player;

public interface ChangeCallback {
	
	void changed();

}
